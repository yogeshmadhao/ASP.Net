﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using SMS_EXCEPTION;
using SMS_ENTITY;
using SMS_DAL;
using System.Text.RegularExpressions;

namespace SMS_BAL
{
   public class StudentValidation
    {
       public static bool ValidateStudent(Student stud)
       {
           bool studValidated = true;
           StringBuilder message = new StringBuilder();
           try
           {
               if(stud.StudCode<=0)
               {
                   studValidated = false;
                   message.Append("Student code should be greater than zero");

               }
                if (stud.StudName == String.Empty)
                {
                    studValidated = false;
                    message.Append("Student name should be provided\n");
                }
                else if (!Regex.IsMatch(stud.StudName, "[A-Z][a-z]+"))
                {
                    studValidated = false;
                    message.Append("Student name should have alphabets only\n");
                }

                if (stud.DOB == null)
                {
                    studValidated = false;
                    message.Append("Student Date of Birth should be provided\n");
                }

                if (studValidated == false)
                    throw new StudentException(message.ToString());
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studValidated;
        }

        public static int InsertStudent(Student stud)
        {
            int recordsAffected = 0;

            try 
            {
                if (ValidateStudent(stud))
                {
                    recordsAffected = StudentOperations.Insert(stud);
                }
                else
                    throw new StudentException("Please provide valid Student Information");
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateStudent(stud))
                {
                    recordsAffected = StudentOperations.Update(stud);
                }
                else
                    throw new StudentException("Please provide valid Student Information");
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteStudent(int studCode)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = StudentOperations.Delete(studCode);
            }
            catch(StudentException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static List<Student> SearchStudent(int studCode)
        {
            
            List<Student> studlist = null;
            try
            {
                studlist = new List<Student>();
                studlist = StudentOperations.Search(studCode);
            }
            catch(StudentException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return studlist;
        }

        public static List<Student> RetrieveStudent()
        {
            List<Student> studList = null;

            try 
            {
                studList = StudentOperations.RetrieveStudent();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
           
       }
    }

