﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using SMS_DAL;
using SMS_ENTITY;
using SMS_EXCEPTION;

namespace SMS_BAL
{
    public class UserValidation
    {
        public static string ValidateLogin(User user)
        {
            string username = null;
            try
            {
                username = UserOperations.ValidateLogin(user);
               
            }
            catch (UserException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return username;
        }
        public static int adduser(User user)
        {
            int add;
            try
            {
                add = UserOperations.AddUser(user);

            }
            catch (UserException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return add;
        }
    }
}
