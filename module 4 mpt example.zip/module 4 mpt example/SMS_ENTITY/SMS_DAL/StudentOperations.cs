﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using SMS_ENTITY;
using SMS_EXCEPTION;

namespace SMS_DAL
{
    public class StudentOperations
    {
        public static int Insert(Student stud)
        {
            int recordAffected = 0;
            SqlCommand cmd = DataConnection.GenerateCommand();
            cmd.CommandText = "usp_InsertStudent";
            cmd.Parameters.AddWithValue("@Stud_Code", stud.StudCode);
            cmd.Parameters.AddWithValue("@Stud_Name", stud.StudName);
            cmd.Parameters.AddWithValue("@Dept_Code", stud.DeptCode);
            cmd.Parameters.AddWithValue("@DOB", stud.DOB);
            cmd.Parameters.AddWithValue("@Address", stud.Address);
            cmd.Connection.Open();
            recordAffected = cmd.ExecuteNonQuery();
            cmd.Connection.Close();
            return recordAffected;
        }
        public static int Update(Student stud)
        {
            int recordsAffected = 0;
            SqlCommand cmd = DataConnection.GenerateCommand();
            cmd.CommandText = "usp_UpdateStudent";
            cmd.Parameters.AddWithValue("@Stud_Code", stud.StudCode);
            cmd.Parameters.AddWithValue("@Dept_Code", stud.DeptCode);
            cmd.Parameters.AddWithValue("@Address", stud.Address);
            cmd.Connection.Open();
            recordsAffected = cmd.ExecuteNonQuery();
            cmd.Connection.Close();
            return recordsAffected;
        }
        public static int Delete(int studCode)
        {
            int recordsAffected = 0;
            SqlCommand cmd = DataConnection.GenerateCommand();
            cmd.CommandText = "usp_DeleteStudent";
            cmd.Parameters.AddWithValue("@Stud_Code", studCode);
            cmd.Connection.Open();
            recordsAffected = cmd.ExecuteNonQuery();
            cmd.Connection.Close();
            return recordsAffected;
        }
        public static List<Student> Search(int studCode)
        {
            Student stud = null;
            List<Student> studlist = null;
            SqlCommand cmd = DataConnection.GenerateCommand();
            cmd.CommandText = "usp_SearchStudent";
            cmd.Parameters.AddWithValue("@Stud_Code", studCode);
            cmd.Connection.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                stud = new Student();
                studlist = new List<Student>();
               
                stud.StudCode = (int)(decimal)dr["Stud_Code"];
                stud.StudName = dr["Stud_name"].ToString();
                stud.DeptCode =Convert.ToInt32( dr["Dept_Code"]);
                stud.DOB = Convert.ToDateTime(dr["Stud_Dob"]);
                stud.Address = dr["Address"].ToString();
                studlist.Add(stud);
               
            }
            return studlist;
        }
        public static List<Student> RetrieveStudent()
        {
            List<Student> studlist = null;
            SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayStudent";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    studlist = new List<Student>();
                    while (dr.Read())
                    {
                        Student stud = new Student();

                        stud.StudCode = (int)(decimal)dr["Stud_Code"];
                        stud.StudName = dr["Stud_name"].ToString();
                        stud.DeptCode = (int)(decimal)dr["Dept_Code"];
                        stud.DOB = Convert.ToDateTime(dr["Stud_Dob"]);
                        stud.Address = dr["Address"].ToString();

                        studlist.Add(stud);
                    }
                }
                return studlist;


            }
    }
}
