﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_EXCEPTION;
using SMS_ENTITY;
using System.Data.SqlClient;

namespace SMS_DAL
{
  public  class UserOperations
    {
      public static string ValidateLogin(User user)
      {
          string username = null;
          SqlCommand cmd = DataConnection.GenerateCommand();
          cmd.CommandText = "usp_ValidateLogin_138214C";
          cmd.Parameters.AddWithValue("@UserName", user.UserName);
          cmd.Parameters.AddWithValue("@Password", user.Password);
          cmd.Connection.Open();
          SqlDataReader dr = cmd.ExecuteReader();
          if(dr.HasRows)
          {
              dr.Read();
              username = dr["UserName"].ToString();
          }
          cmd.Connection.Close();
          return username;
      }
      public static int AddUser(User user)
      {
          SqlCommand cmd = DataConnection.GenerateCommand();
          cmd.CommandText = "usp_newUser_138214";
          cmd.Parameters.AddWithValue("@UserName", user.UserName);
          cmd.Parameters.AddWithValue("@Password", user.Password);
          cmd.Connection.Open();
          int row = cmd.ExecuteNonQuery();
          cmd.Connection.Close();
          return row;
      }
    }
}
