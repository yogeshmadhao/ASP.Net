﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using SMS_ENTITY;
using SMS_EXCEPTION;
using SMS_BAL;

namespace SMS_PL
{
    public partial class Search : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
            
        }

        protected void btn_Click(object sender, EventArgs e)
        {
            List<Student> stud=null;
            int code=Convert.ToInt32(txtcode.Text);
            stud = StudentValidation.SearchStudent(code);
            gvstudent.DataSource = stud;
            gvstudent.DataBind();
        }
    }
}