﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS_BAL;
using SMS_EXCEPTION;
using SMS_ENTITY;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SMS_PL
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                lblwelcome.Text = "welcome" + Session["user"].ToString();
            }
            else
                Response.Redirect("Login.aspx");
            Master.Logout = true;
            Master.Menu = true;
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
                SqlDataAdapter da = new SqlDataAdapter("select * from student_master", con);
                DataSet ds = new DataSet();
                da.Fill(ds, "stud");
                gvstudent.DataSource = ds.Tables["Stud"];
                gvstudent.DataBind();
            }
            catch(StudentException ex)
            {
                Response.Write(",script>alert('" + ex.Message + "');</script>");
            }
            catch(SystemException ex)
            {
                Response.Write(",script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}