﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS_BAL;
using SMS_ENTITY;
using SMS_EXCEPTION;

namespace SMS_PL
{
    public partial class _new : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Click(object sender, EventArgs e)
        {
            try
            {
                Student stud = new Student();
                User user = new User();
                stud.StudCode = Convert.ToInt32(txtcode.Text);
                stud.StudName = txtname.Text;
                stud.DeptCode = Convert.ToInt32(txtdeptcode.Text);
                stud.DOB = Convert.ToDateTime(txtdob.Text);
                stud.Address = txtaddress.Text;
                user.UserName = txtuser.Text;
                user.Password = txtpass.Text;
                int studadd = StudentValidation.InsertStudent(stud);
                int useradded = UserValidation.adduser(user);
              
                if(studadd!=0)
                {
                    Response.Write("<script>alert('Record Added Successfully');</script>");
                    Response.Redirect("Home.aspx");

                }
            }
            catch (UserException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}