﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS_PL
{
    public partial class StudentMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public bool Logout
        {
            get { return divlogout.Visible; }
            set { divlogout.Visible = value; }
        }
        public bool Menu
        {
            get { return divmenu.Visible; }
            set { divmenu.Visible = value; }
        }
        protected void btnlogout_Click(object sender, EventArgs e)
        {
            Session["user"] = null;
            Response.Redirect("Login.aspx");
        }
    }
}