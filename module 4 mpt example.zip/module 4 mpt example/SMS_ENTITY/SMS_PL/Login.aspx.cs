﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS_EXCEPTION;
using SMS_ENTITY;
using SMS_BAL;

namespace SMS_PL
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                User user = new User() { UserName = txtuserid.Text, Password = txtpass.Text };
                string username = UserValidation.ValidateLogin(user);
                if(username==null || username== "")
                {
                    throw new UserException("User Id/Password is wrong");

                }
                else
                {
                    Session["user"]=username;
                    Response.Redirect("Home.aspx");
                }
            }
            catch(UserException ex)
            {
                Response.Write("<script>alert('"+ex.Message+"');</script>");
            }
            catch(SystemException ex)
            {
                  Response.Write("<script>alert('"+ex.Message+"');</script>");
           }
        }

        protected void btnnew_Click(object sender, EventArgs e)
        {
            Response.Redirect("new.aspx");
        }
    }
}